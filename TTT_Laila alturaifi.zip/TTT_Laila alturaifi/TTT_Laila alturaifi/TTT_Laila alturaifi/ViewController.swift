//
//  ViewController.swift
//  TTT_Laila alturaifi
//
//  Created by administrator on 05/12/2021.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var but1: UIButton!
    @IBOutlet weak var but2: UIButton!
    @IBOutlet weak var but3: UIButton!
    @IBOutlet weak var but4: UIButton!
    @IBOutlet weak var but5: UIButton!
    @IBOutlet weak var but6: UIButton!
    @IBOutlet weak var but7: UIButton!
    @IBOutlet weak var but8: UIButton!
    @IBOutlet weak var but9: UIButton!
    
    @IBOutlet weak var ResultLabel: UILabel!
    
    var player = 1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        but1.backgroundColor = .white;
        but2.backgroundColor = .white;
        but3.backgroundColor = .white;
        but4.backgroundColor = .white;
        but5.backgroundColor = .white;
        but6.backgroundColor = .white;
        but7.backgroundColor = .white;
        but8.backgroundColor = .white;
        but9.backgroundColor = .white;
        
        but1.setTitle("-", for: .normal)
        but1.setTitleColor(.black, for: .normal)
        but1.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but2.setTitle("-", for: .normal)
        but2.setTitleColor(.black, for: .normal)
        but2.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but3.setTitle("-", for: .normal)
        but3.setTitleColor(.black, for: .normal)
        but3.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but4.setTitle("-", for: .normal)
        but4.setTitleColor(.black, for: .normal)
        but4.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but5.setTitle("-", for: .normal)
        but5.setTitleColor(.black, for: .normal)
        but5.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but6.setTitle("-", for: .normal)
        but6.setTitleColor(.black, for: .normal)
        but6.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but7.setTitle("-", for: .normal)
        but7.setTitleColor(.black, for: .normal)
        but7.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but8.setTitle("-", for: .normal)
        but8.setTitleColor(.black, for: .normal)
        but8.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but9.setTitle("-", for: .normal)
        but9.setTitleColor(.black, for: .normal)
        but9.titleLabel?.font  = .systemFont(ofSize: 66)
        
    }
    
    func WinirCases () {
        if (but1.backgroundColor == UIColor.red) && (but2.backgroundColor == .red) && (but3.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }else if (but4.backgroundColor == .red) && (but5.backgroundColor == .red) && (but6.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }else if (but7.backgroundColor == .red) && (but8.backgroundColor == .red) && (but9.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }else if (but1.backgroundColor == .red) && (but4.backgroundColor == .red) && (but7.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }else if (but2.backgroundColor == .red) && (but5.backgroundColor == .red) && (but8.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }else if (but3.backgroundColor == .red) && (but6.backgroundColor == .red) && (but9.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }else if (but1.backgroundColor == .red) && (but5.backgroundColor == .red) && (but9.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        } else if (but3.backgroundColor == .red) && (but5.backgroundColor == .red) && (but7.backgroundColor == .red){
            ResultLabel.text = "Congrat Red Won"
            ResultLabel.textColor = UIColor.red
            
        }
        
        else if (but1.backgroundColor == .blue) && (but2.backgroundColor == .blue) && (but3.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }else if (but4.backgroundColor == .blue) && (but5.backgroundColor == .blue) && (but6.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }else if (but7.backgroundColor == .blue) && (but8.backgroundColor == .blue) && (but9.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }else if (but1.backgroundColor == .blue) && (but4.backgroundColor == .blue) && (but7.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }else if (but2.backgroundColor == .blue) && (but5.backgroundColor == .blue) && (but8.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }else if (but3.backgroundColor == .blue) && (but6.backgroundColor == .blue) && (but9.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }else if (but1.backgroundColor == .blue) && (but5.backgroundColor == .blue) && (but9.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        } else if (but3.backgroundColor == .blue) && (but5.backgroundColor == .blue) && (but7.backgroundColor == .blue){
            ResultLabel.text = "Congrat Bule Won"
            ResultLabel.textColor = UIColor.blue
            
        }
        if (but1.backgroundColor == .blue || but1.backgroundColor == .red) && (but2.backgroundColor == .blue || but2.backgroundColor == .red) && (but3.backgroundColor == .blue || but3.backgroundColor == .red) && (but4.backgroundColor == .blue || but4.backgroundColor == .red) && (but5.backgroundColor == .blue || but5.backgroundColor == .red) && (but6.backgroundColor == .blue || but6.backgroundColor == .red) && (but7.backgroundColor == .blue || but7.backgroundColor == .red) && (but8.backgroundColor == .blue || but8.backgroundColor == .red) && (but9.backgroundColor == .blue || but9.backgroundColor == .red) {
            ResultLabel.text = "No One Won"
            ResultLabel.textColor = UIColor.black
        }
    }
    
    @IBAction func Button1(_ sender: UIButton) {
        if (but1.backgroundColor == .white){
            if player == 1{
                but1.backgroundColor = UIColor.red
                player = 2
                
                but1.setTitle("X", for: .normal)
                but1.setTitleColor(.red, for: .normal)
                but1.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but1.backgroundColor = UIColor.blue
                player = 1
                
                but1.setTitle("O", for: .normal)
                but1.setTitleColor(.blue, for: .normal)
                but1.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button2(_ sender: UIButton) {
        if (but2.backgroundColor == .white){
            if player == 1{
                but2.backgroundColor = UIColor.red
                player = 2
                
                but2.setTitle("X", for: .normal)
                but2.setTitleColor(.red, for: .normal)
                but2.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but2.backgroundColor = UIColor.blue
                player = 1
                
                but2.setTitle("O", for: .normal)
                but2.setTitleColor(.blue, for: .normal)
                but2.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button3(_ sender: Any) {
        if (but3.backgroundColor == .white){
            if player == 1{
                but3.backgroundColor = UIColor.red
                player = 2
                
                but3.setTitle("X", for: .normal)
                but3.setTitleColor(.red, for: .normal)
                but3.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but3.backgroundColor = UIColor.blue
                player = 1
                
                but3.setTitle("O", for: .normal)
                but3.setTitleColor(.blue, for: .normal)
                but3.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button4(_ sender: UIButton) {
        if (but4.backgroundColor == .white){
            if player == 1{
                but4.backgroundColor = UIColor.red
                player = 2
                
                but4.setTitle("X", for: .normal)
                but4.setTitleColor(.red, for: .normal)
                but4.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but4.backgroundColor = UIColor.blue
                player = 1
                
                but4.setTitle("O", for: .normal)
                but4.setTitleColor(.blue, for: .normal)
                but4.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button5(_ sender: UIButton) {
        if (but5.backgroundColor == .white){
            if player == 1{
                but5.backgroundColor = UIColor.red
                player = 2
                
                but5.setTitle("X", for: .normal)
                but5.setTitleColor(.red, for: .normal)
                but5.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but5.backgroundColor = UIColor.blue
                player = 1
                
                but5.setTitle("O", for: .normal)
                but5.setTitleColor(.blue, for: .normal)
                but5.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button6(_ sender: UIButton) {
        if (but6.backgroundColor == .white){
            if player == 1{
                but6.backgroundColor = UIColor.red
                player = 2
                
                but6.setTitle("X", for: .normal)
                but6.setTitleColor(.red, for: .normal)
                but6.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but6.backgroundColor = UIColor.blue
                player = 1
                
                but6.setTitle("O", for: .normal)
                but6.setTitleColor(.blue, for: .normal)
                but6.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button7(_ sender: UIButton) {
        if (but7.backgroundColor == .white){
            if player == 1{
                but7.backgroundColor = UIColor.red
                player = 2
                
                but7.setTitle("X", for: .normal)
                but7.setTitleColor(.red, for: .normal)
                but7.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but7.backgroundColor = UIColor.blue
                player = 1
                
                but7.setTitle("O", for: .normal)
                but7.setTitleColor(.blue, for: .normal)
                but7.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button8(_ sender: UIButton) {
        if (but8.backgroundColor == .white){
            if player == 1{
                but8.backgroundColor = UIColor.red
                player = 2
                
                but8.setTitle("X", for: .normal)
                but8.setTitleColor(.red, for: .normal)
                but8.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but8.backgroundColor = UIColor.blue
                player = 1
                
                but8.setTitle("O", for: .normal)
                but8.setTitleColor(.blue, for: .normal)
                but8.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    @IBAction func Button9(_ sender: UIButton) {
        if (but9.backgroundColor == .white){
            if player == 1{
                but9.backgroundColor = UIColor.red
                player = 2
                
                but9.setTitle("X", for: .normal)
                but9.setTitleColor(.red, for: .normal)
                but9.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }else{
                but9.backgroundColor = UIColor.blue
                player = 1
                
                but9.setTitle("O", for: .normal)
                but9.setTitleColor(.blue, for: .normal)
                but9.titleLabel?.font  = .systemFont(ofSize: 33)
                
            }
            WinirCases()
        }
    }
    
    
    @IBAction func RestartButton(_ sender: UIButton) {
        but1.backgroundColor = .white;
        but2.backgroundColor = .white;
        but3.backgroundColor = .white;
        but4.backgroundColor = .white;
        but5.backgroundColor = .white;
        but6.backgroundColor = .white;
        but7.backgroundColor = .white;
        but8.backgroundColor = .white;
        but9.backgroundColor = .white;
        
        but1.setTitle("-", for: .normal)
        but1.setTitleColor(.black, for: .normal)
        but1.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but2.setTitle("-", for: .normal)
        but2.setTitleColor(.black, for: .normal)
        but2.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but3.setTitle("-", for: .normal)
        but3.setTitleColor(.black, for: .normal)
        but3.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but4.setTitle("-", for: .normal)
        but4.setTitleColor(.black, for: .normal)
        but4.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but5.setTitle("-", for: .normal)
        but5.setTitleColor(.black, for: .normal)
        but5.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but6.setTitle("-", for: .normal)
        but6.setTitleColor(.black, for: .normal)
        but6.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but7.setTitle("-", for: .normal)
        but7.setTitleColor(.black, for: .normal)
        but7.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but8.setTitle("-", for: .normal)
        but8.setTitleColor(.black, for: .normal)
        but8.titleLabel?.font  = .systemFont(ofSize: 66)
        
        but9.setTitle("-", for: .normal)
        but9.setTitleColor(.black, for: .normal)
        but9.titleLabel?.font  = .systemFont(ofSize: 66)
        
        ResultLabel.text = "Result"
        
    }
    
}

